<div class="panel panel-default" style="background-color: pink; height: 50px; position: fixed; bottom: 0%; width: 100%;text-align: center;" >
  <div class="panel-body" style="font-size: 20px;color: rgb(235, 44, 75)">
    FREE DELIVERY ON ORDERS OVER Rs: 5,000.00
  </div>
</div>